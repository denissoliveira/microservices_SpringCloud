package br.com.microservice.project.loja.entity;

public enum CompraStatus {
	RECEBIDO, PREDIDO_REALIZADO, RESERVA_ENTREGA_REALIZADA, CANCELADO;
}
