INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(1, 'Rua Elizeth Cardoso, 1212, RJ', 1, 23, NOW(), 1, 'RECEBIDO');
INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(2, 'Rua Mirindiba, 12, RJ', 2, 9, NOW(), 2, 'RECEBIDO');
INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(3, 'Rua Madri, 589, RJ', 3, 7, NOW(), 3, 'RECEBIDO');
INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(4, 'Travessa do Migrantes, 12, RJ', 4, 9, NOW(), 4, 'RECEBIDO');
INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(5, 'Rua Almir Queirós, 87, RJ', 5, 21, NOW(), 5, 'RECEBIDO');
INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(6, 'Rua Paraná, 147, RJ', 6, 14, NOW(), 6, 'RECEBIDO');
INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(7, 'Rua Caetite, 956, RJ', 7, 6, NOW(), 7, 'RECEBIDO');
INSERT INTO compra(id, endereco_destino, pedido_id, tempo_de_preparo, data_para_entrega, voucher, status)VALUES(8, 'Avenida FAB, 25, RJ', 8, 14, NOW(), 8, 'RECEBIDO');
