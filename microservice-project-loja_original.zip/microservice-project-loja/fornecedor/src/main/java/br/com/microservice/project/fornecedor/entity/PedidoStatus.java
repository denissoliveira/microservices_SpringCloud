package br.com.microservice.project.fornecedor.entity;

public enum PedidoStatus {
	RECEBIDO, PRONTO, ENVIADO;
}
