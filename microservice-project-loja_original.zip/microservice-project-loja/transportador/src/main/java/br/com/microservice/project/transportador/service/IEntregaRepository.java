package br.com.microservice.project.transportador.service;

public interface IEntregaRepository {

}
